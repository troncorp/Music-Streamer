class SongTile {
  final thumbnail;
  final title;
  final url;
  final duration;

  SongTile({this.url, this.thumbnail, this.duration, this.title});
}
