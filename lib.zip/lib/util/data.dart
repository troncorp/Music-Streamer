import '../model/song_tile.dart';

List<SongTile> kSongs = [];

String kLangSel = '';
